package com.example.explicitintent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.explicitintent.R;

public class MainActivity extends AppCompatActivity {

    // Declare UI elements
    private LinearLayout loginLayout, profileLayout;
    private EditText etUsername, etPassword;
    private Button btnLogin, btnLogout;
    private TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Initialize UI elements
        loginLayout = findViewById(R.id.loginLayout);
        profileLayout = findViewById(R.id.profileLayout);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnLogout = findViewById(R.id.btnLogout);
        tvWelcome = findViewById(R.id.tvWelcome);

        // Handle Login Button Click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = etUsername.getText().toString().trim();
                String pass = etPassword.getText().toString().trim();

                // Validation Logic
                if (user.equals("admin") && pass.equals("1234")) {
                    // Success: Toggle Visibility
                    loginLayout.setVisibility(View.GONE);
                    profileLayout.setVisibility(View.VISIBLE);
                    tvWelcome.setText("Welcome, " + user + "!");
                    Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                } else {
                    // Failure: Show Error
                    Toast.makeText(MainActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle Logout Button Click
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Clear inputs and return to login screen
                etUsername.setText("");
                etPassword.setText("");
                loginLayout.setVisibility(View.VISIBLE);
                profileLayout.setVisibility(View.GONE);
            }
        });
    }
}